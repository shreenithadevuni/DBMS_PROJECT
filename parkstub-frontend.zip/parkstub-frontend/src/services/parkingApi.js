import { PLACES } from "../data/places";
import { slotsFor } from "../utils/format";

/**
 * Mock API layer standing in for your Node/Express backend.
 * Every function returns a Promise so swapping in real fetch() calls
 * later (e.g. to /api/places, /api/bookings) won't touch calling code.
 */
const LATENCY = 250;
const wait = (ms) => new Promise((res) => setTimeout(res, ms));

export async function fetchPlaces({ query = "", city = "All Cities", type = "All Types" } = {}) {
  await wait(LATENCY);
  const q = query.trim().toLowerCase();
  return PLACES.filter((p) => {
    const matchQ = !q || p.name.toLowerCase().includes(q) || p.city.toLowerCase().includes(q) || p.area.toLowerCase().includes(q);
    const matchCity = city === "All Cities" || p.city === city;
    const matchType = type === "All Types" || p.type === type;
    return matchQ && matchCity && matchType;
  });
}

export async function fetchPlaceById(id) {
  await wait(LATENCY);
  return PLACES.find((p) => p.id === Number(id)) || null;
}

export async function fetchSlots(place, dateStr) {
  await wait(LATENCY);
  return slotsFor(place, dateStr);
}

// Simulates handing off to Razorpay and getting a success callback.
export async function createPaymentOrder(amount) {
  await wait(900);
  return { orderId: "order_" + Math.random().toString(36).slice(2, 10), amount, status: "created" };
}

export async function verifyPayment(orderId) {
  await wait(600);
  return { orderId, status: "paid" };
}
