export function hashStr(s) {
  let h = 0;
  for (let i = 0; i < s.length; i++) {
    h = (h << 5) - h + s.charCodeAt(i);
    h |= 0;
  }
  return Math.abs(h);
}

export function mulberry32(a) {
  return function () {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

export function seededRand(seed) {
  return mulberry32(hashStr(String(seed)));
}

export function fmtINR(n) {
  return "₹" + Math.round(n).toLocaleString("en-IN");
}

export function todayStr() {
  return new Date().toISOString().slice(0, 10);
}

export function genBookingCode(id) {
  return "PS" + String(id).padStart(6, "0");
}

export function isPastBooking(booking) {
  const dt = new Date(`${booking.date}T${booking.startTime}:00`);
  return dt.getTime() < Date.now();
}

/**
 * Deterministic parking-bay layout for a given place + date, so the
 * same date always shows the same mock availability during a session.
 */
export function slotsFor(place, dateStr) {
  const rnd = seededRand(place.id + "-" + dateStr);
  const total = Math.min(place.slots, 48); // visual grid cap
  const rows = "ABCD";
  const perRow = Math.ceil(total / 4);
  const out = [];
  let i = 0;
  for (const r of rows) {
    for (let c = 1; c <= perRow; c++) {
      if (i >= total) break;
      const v = rnd();
      let status = "available";
      if (v < 0.32) status = "occupied";
      else if (v < 0.42) status = "reserved";
      out.push({ code: r + c, status });
      i++;
    }
  }
  return out;
}

/** Deterministic "how full is this place right now" number for cards. */
export function availabilityFor(place) {
  const rnd = seededRand(place.id + "-avail");
  const pct = 0.15 + rnd() * 0.8;
  return { pct, count: Math.round(place.slots * pct) };
}

/** Builds a pseudo-QR grid (visual only, not a real scannable code). */
export function fakeQrCells(seed, size = 21) {
  const rnd = seededRand(seed + "-qr");
  const cells = [];
  for (let y = 0; y < size; y++) {
    for (let x = 0; x < size; x++) {
      const isFinder = (x < 5 && y < 5) || (x > size - 6 && y < 5) || (x < 5 && y > size - 6);
      const on = isFinder ? x % 6 < 4 && y % 6 < 4 : rnd() > 0.55;
      if (on) cells.push([x, y]);
    }
  }
  return { size, cells };
}
