import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import Footer from "../components/Footer";
import { useAuth } from "../context/AuthContext";

export default function Login() {
  const { login } = useAuth();
  const navigate = useNavigate();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");

  const submit = (e) => {
    e.preventDefault();
    const result = login({ email, password });
    if (result.ok) {
      navigate("/");
    } else {
      setError(result.error);
    }
  };

  return (
    <div className="page view-enter">
      <div className="auth-wrap">
        <div className="auth-card">
          <h2>Log in</h2>
          <div className="sub">Welcome back — enter your details to continue.</div>

          {error && <div className="auth-error">{error}</div>}

          <form onSubmit={submit}>
            <div className="field">
              <label>Email ID</label>
              <input value={email} onChange={(e) => setEmail(e.target.value)} placeholder="you@example.com" />
            </div>
            <div className="field">
              <label>Password</label>
              <input type="password" value={password} onChange={(e) => setPassword(e.target.value)} placeholder="Your password" />
            </div>
            <button className="btn-amber block" type="submit" style={{ marginTop: 6 }}>
              Log in
            </button>
          </form>

          <div className="auth-switch">
            New here? <Link to="/signup">Create an account</Link>
          </div>
        </div>
      </div>
      <Footer />
    </div>
  );
}
