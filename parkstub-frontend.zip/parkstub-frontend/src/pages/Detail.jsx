import { useEffect, useMemo, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import Icon, { TYPE_ICON } from "../components/Icon";
import SlotMap from "../components/SlotMap";
import Footer from "../components/Footer";
import { PLACES, TYPE_COLOR } from "../data/places";
import { availabilityFor, fmtINR, slotsFor, todayStr } from "../utils/format";
import { useBookings } from "../context/BookingContext";
import { useToast } from "../context/ToastContext";

const DURATIONS = [1, 2, 3, 4, 6, 8];

export default function Detail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const showToast = useToast();
  const { draft, setDraft } = useBookings();
  const place = PLACES.find((p) => p.id === Number(id));

  const initial = draft && draft.placeId === Number(id) ? draft : null;
  const [date, setDate] = useState(initial?.date || todayStr());
  const [startTime, setStartTime] = useState(initial?.startTime || "10:00");
  const [duration, setDuration] = useState(initial?.duration || 2);
  const [slotCode, setSlotCode] = useState(initial?.slotCode || null);

  useEffect(() => {
    // reset the chosen bay whenever the date changes, since availability is per-date
    setSlotCode(null);
  }, [date]);

  const slots = useMemo(() => (place ? slotsFor(place, date) : []), [place, date]);
  const availCount = slots.filter((s) => s.status === "available").length;
  const { count: liveAvail } = place ? availabilityFor(place) : { count: 0 };
  const fee = place ? place.price * duration : 0;

  if (!place) {
    navigate("/results");
    return null;
  }

  const reserve = () => {
    if (!slotCode) {
      showToast("Pick an available bay first");
      return;
    }
    setDraft({ placeId: place.id, date, startTime, duration, slotCode });
    navigate("/checkout");
  };

  return (
    <div className="page view-enter">
      <button className="back-link" onClick={() => navigate("/results")}>
        <Icon name="arrowLeft" size={14} /> Back to results
      </button>

      <div className="detail-header">
        <div>
          <div className="detail-hero-media" style={{ color: TYPE_COLOR[place.type] }}>
            <Icon name={TYPE_ICON[place.type]} size={56} />
          </div>
          <div className="detail-title">{place.name}</div>
          <div className="detail-address">
            {place.area}, {place.city}, Telangana &middot; {place.type}
          </div>

          <div className="stat-row">
            <div>
              <div className="stat-num">{place.slots}</div>
              <div className="stat-label">Total bays</div>
            </div>
            <div>
              <div className="stat-num" style={{ color: "var(--green)" }}>
                {liveAvail}
              </div>
              <div className="stat-label">Free right now</div>
            </div>
            <div>
              <div className="stat-num">{fmtINR(place.price)}</div>
              <div className="stat-label">Per hour</div>
            </div>
          </div>

          <SlotMap slots={slots} selectedCode={slotCode} onSelect={setSlotCode} />
        </div>

        <div className="side-card">
          <h4>
            <Icon name="calendar" size={16} />
            Reserve a bay
          </h4>
          <div className="field">
            <label>Date</label>
            <input type="date" value={date} min={todayStr()} onChange={(e) => setDate(e.target.value)} />
          </div>
          <div className="field">
            <label>Start time</label>
            <input type="time" value={startTime} onChange={(e) => setStartTime(e.target.value)} />
          </div>
          <div className="field">
            <label>Duration</label>
            <select value={duration} onChange={(e) => setDuration(Number(e.target.value))}>
              {DURATIONS.map((h) => (
                <option key={h} value={h}>
                  {h} hour{h > 1 ? "s" : ""}
                </option>
              ))}
            </select>
          </div>
          <div className="field">
            <label>Selected bay</label>
            <input type="text" value={slotCode || "Tap a bay in the map"} disabled />
          </div>

          <div style={{ marginTop: 18 }}>
            <div className="fee-line">
              <span>Rate</span>
              <span>
                {fmtINR(place.price)} &times; {duration}h
              </span>
            </div>
            <div className="fee-total">
              <span>Total</span>
              <span>{fmtINR(fee)}</span>
            </div>
          </div>

          <button
            className="btn-amber block"
            style={{ marginTop: 16 }}
            disabled={!slotCode}
            onClick={reserve}
          >
            Reserve &amp; pay <Icon name="arrowRight" size={16} />
          </button>
          <div style={{ color: "var(--ink-dim)", fontSize: 12, marginTop: 8 }}>
            {availCount} of {slots.length} shown bays free for this date
          </div>
        </div>
      </div>
      <Footer />
    </div>
  );
}
