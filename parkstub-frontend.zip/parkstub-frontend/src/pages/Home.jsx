import { useState } from "react";
import { useNavigate, Link } from "react-router-dom";
import Icon from "../components/Icon";
import PlaceCard from "../components/PlaceCard";
import Footer from "../components/Footer";
import { PLACES, CITIES } from "../data/places";
import { useAuth } from "../context/AuthContext";

const STEPS = [
  ["01", "Search", "Find a mall or landmark"],
  ["02", "Pick a slot", "Choose date, time & bay"],
  ["03", "Pay online", "Razorpay-secured checkout"],
  ["04", "Get your ticket", "Unique QR generated instantly"],
  ["05", "Scan at entry", "Booking verified on arrival"],
  ["06", "Park", "Straight to your reserved bay"],
];

export default function Home() {
  const [query, setQuery] = useState("");
  const navigate = useNavigate();
  const { currentUser } = useAuth();
  const featured = PLACES.slice(0, 8);

  const search = () => navigate(`/results?q=${encodeURIComponent(query)}`);

  return (
    <div className="view-enter">
      <div className="hero">
        <div className="hero-inner">
          {currentUser && (
            <div style={{ color: "var(--ink-dim)", fontSize: 14, marginBottom: 10 }}>
              Welcome back, <b style={{ color: "var(--ink)" }}>{currentUser.name || "there"}</b>
            </div>
          )}
          <div className="eyebrow">Telangana &middot; Malls, Temples, Forts &amp; More</div>
          <h1>
            Reserve your parking
            <br />
            <em>before</em> you arrive.
          </h1>
          <p className="lede">
            Search 40+ malls and landmarks across Telangana, pick a slot, pay online, and walk in on a
            QR-verified ticket — no more circling the lot.
          </p>
          <div className="search-ticket">
            <div className="search-input-wrap">
              <Icon name="search" />
              <input
                placeholder="Search a mall, temple, fort, or city..."
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && search()}
              />
            </div>
            <button className="btn-amber" onClick={search}>
              Search <Icon name="arrowRight" size={16} />
            </button>
          </div>
          <div className="city-chips">
            {CITIES.slice(0, 7).map((c) => (
              <Link key={c} to={`/results?city=${encodeURIComponent(c)}`} className="chip">
                {c}
              </Link>
            ))}
          </div>
        </div>
        <div className="hero-stripe-edge barrier-stripes"></div>
      </div>

      <div className="page">
        <div className="section-head">
          <div>
            <div className="section-title">Featured destinations</div>
            <div className="section-sub">Popular spots being booked right now</div>
          </div>
          <Link to="/results" className="btn-ghost">
            View all 40 &rarr;
          </Link>
        </div>
        <div className="place-grid">
          {featured.map((p) => (
            <PlaceCard key={p.id} place={p} />
          ))}
        </div>

        <div className="section-head">
          <div>
            <div className="section-title">How it works</div>
            <div className="section-sub">Six steps from search to a parked car</div>
          </div>
        </div>
        <div className="place-grid" style={{ gridTemplateColumns: "repeat(auto-fill,minmax(180px,1fr))" }}>
          {STEPS.map(([n, t, d]) => (
            <div className="place-card" style={{ cursor: "default" }} key={n}>
              <div className="step-mini">
                <div className="n">{n}</div>
                <div className="t">{t}</div>
                <div className="d">{d}</div>
              </div>
            </div>
          ))}
        </div>
      </div>
      <Footer />
    </div>
  );
}
