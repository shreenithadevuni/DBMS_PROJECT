import { Navigate } from "react-router-dom";
import Footer from "../components/Footer";
import { useAuth } from "../context/AuthContext";
import { useBookings } from "../context/BookingContext";

export default function Profile() {
  const { currentUser } = useAuth();
  const { bookings } = useBookings();

  if (!currentUser) return <Navigate to="/login" replace />;

  const upcoming = bookings.filter((b) => b.status === "confirmed").length;

  return (
    <div className="page view-enter">
      <div className="section-head tight">
        <div>
          <div className="section-title">My profile</div>
          <div className="section-sub">Your account information</div>
        </div>
      </div>

      <div className="side-card profile-card">
        <div className="profile-row">
          <span className="k">Name</span>
          <span className="v">{currentUser.name || "—"}</span>
        </div>
        <div className="profile-row">
          <span className="k">Phone number</span>
          <span className="v">{currentUser.phone || "—"}</span>
        </div>
        <div className="profile-row">
          <span className="k">Email ID</span>
          <span className="v">{currentUser.email || "—"}</span>
        </div>
        <div className="profile-row">
          <span className="k">Account type</span>
          <span className="v">{currentUser.role}</span>
        </div>
        <div className="profile-row">
          <span className="k">Upcoming bookings</span>
          <span className="v">{upcoming}</span>
        </div>
      </div>
      <Footer />
    </div>
  );
}
