import { Link, useNavigate, useParams } from "react-router-dom";
import Icon from "../components/Icon";
import TicketStub from "../components/TicketStub";
import Footer from "../components/Footer";
import { useBookings } from "../context/BookingContext";

export default function Confirmation() {
  const { bookingId } = useParams();
  const navigate = useNavigate();
  const { bookings } = useBookings();
  const booking = bookings.find((b) => b.id === Number(bookingId));

  if (!booking) {
    navigate("/");
    return null;
  }

  return (
    <div className="page view-enter">
      <div className="confirm-wrap">
        <div className="confirm-icon">
          <Icon name="check" size={30} />
        </div>
        <h2>Booking confirmed</h2>
        <p>Show this QR ticket at the entrance of {booking.placeName}.</p>
        <TicketStub booking={booking} />
        <div className="confirm-actions">
          <Link to="/" className="btn-ghost">
            <Icon name="home" size={15} style={{ verticalAlign: "-2px", marginRight: 6 }} />
            Back to home
          </Link>
          <Link to="/bookings" className="btn-amber">
            View my bookings <Icon name="arrowRight" size={16} />
          </Link>
        </div>
      </div>
      <Footer />
    </div>
  );
}
