import Footer from "../components/Footer";
import { PLACES } from "../data/places";
import { fmtINR, genBookingCode } from "../utils/format";
import { useBookings } from "../context/BookingContext";

export default function Admin() {
  const { bookings } = useBookings();
  const totalBookings = bookings.length;
  const revenue = bookings.filter((b) => b.status === "confirmed").reduce((s, b) => s + b.amount, 0);
  const cancelled = bookings.filter((b) => b.status === "cancelled").length;
  const refunded = bookings.filter((b) => b.status === "cancelled").reduce((s, b) => s + (b.refund || 0), 0);
  const totalBays = PLACES.reduce((s, p) => s + p.slots, 0);

  return (
    <div className="page view-enter">
      <div className="section-head tight">
        <div>
          <div className="section-title">Admin overview</div>
          <div className="section-sub">Live snapshot across all 40 locations (demo data)</div>
        </div>
      </div>

      <div className="admin-stats">
        <Stat num={PLACES.length} label="Locations" />
        <Stat num={totalBays.toLocaleString("en-IN")} label="Total bays" />
        <Stat num={totalBookings} label="Bookings (session)" />
        <Stat num={fmtINR(revenue)} label="Revenue collected" />
        <Stat num={cancelled} label="Cancellations" />
        <Stat num={fmtINR(refunded)} label="Refunded" />
      </div>

      <div className="section-title" style={{ marginBottom: 14 }}>
        Recent bookings
      </div>
      <div className="table-wrap">
        <table className="admin-table">
          <thead>
            <tr>
              <th>Ticket</th>
              <th>Location</th>
              <th>Date</th>
              <th>Bay</th>
              <th>Amount</th>
              <th>Status</th>
            </tr>
          </thead>
          <tbody>
            {bookings.length ? (
              bookings.map((b) => (
                <tr key={b.id}>
                  <td>{genBookingCode(b.id)}</td>
                  <td>{b.placeName}</td>
                  <td>
                    {b.date} {b.startTime}
                  </td>
                  <td>{b.slotCode}</td>
                  <td>{fmtINR(b.amount)}</td>
                  <td style={{ color: b.status === "confirmed" ? "var(--green)" : "var(--red)" }}>{b.status}</td>
                </tr>
              ))
            ) : (
              <tr>
                <td colSpan={6} style={{ textAlign: "center", color: "var(--ink-dim)", padding: 26 }}>
                  No bookings yet this session.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
      <Footer />
    </div>
  );
}

function Stat({ num, label }) {
  return (
    <div className="admin-stat">
      <div className="num">{num}</div>
      <div className="lbl">{label}</div>
    </div>
  );
}
