import { useMemo } from "react";
import { useSearchParams } from "react-router-dom";
import Icon from "../components/Icon";
import PlaceCard from "../components/PlaceCard";
import Footer from "../components/Footer";
import { PLACES, CITIES, TYPES } from "../data/places";

export default function Results() {
  const [params, setParams] = useSearchParams();
  const query = params.get("q") || "";
  const city = params.get("city") || "All Cities";
  const type = params.get("type") || "All Types";

  const setParam = (key, value) => {
    const next = new URLSearchParams(params);
    if (value) next.set(key, value);
    else next.delete(key);
    setParams(next);
  };

  const list = useMemo(() => {
    const q = query.trim().toLowerCase();
    return PLACES.filter((p) => {
      const matchQ = !q || p.name.toLowerCase().includes(q) || p.city.toLowerCase().includes(q) || p.area.toLowerCase().includes(q);
      const matchCity = city === "All Cities" || p.city === city;
      const matchType = type === "All Types" || p.type === type;
      return matchQ && matchCity && matchType;
    });
  }, [query, city, type]);

  return (
    <div className="page view-enter">
      <div className="section-head tight">
        <div>
          <div className="section-title">Find parking</div>
          <div className="section-sub">40 malls &amp; landmarks across Telangana</div>
        </div>
      </div>

      <div className="search-ticket wide">
        <div className="search-input-wrap">
          <Icon name="search" />
          <input
            placeholder="Search by name, area or city..."
            value={query}
            onChange={(e) => setParam("q", e.target.value)}
          />
        </div>
        <button
          className="btn-ghost"
          onClick={() => setParams({})}
        >
          Reset
        </button>
      </div>

      <div className="filters-row">
        <select value={city} onChange={(e) => setParam("city", e.target.value)}>
          {CITIES.map((c) => (
            <option key={c} value={c}>
              {c}
            </option>
          ))}
        </select>
        <select value={type} onChange={(e) => setParam("type", e.target.value)}>
          {TYPES.map((t) => (
            <option key={t} value={t}>
              {t}
            </option>
          ))}
        </select>
        <span className="result-count">
          {list.length} location{list.length !== 1 ? "s" : ""} found
        </span>
      </div>

      <div className="place-grid">
        {list.length ? (
          list.map((p) => <PlaceCard key={p.id} place={p} />)
        ) : (
          <div className="empty-state" style={{ gridColumn: "1/-1" }}>
            <Icon name="search" size={32} />
            <div>No matches. Try a different search or clear filters.</div>
          </div>
        )}
      </div>
      <Footer />
    </div>
  );
}
