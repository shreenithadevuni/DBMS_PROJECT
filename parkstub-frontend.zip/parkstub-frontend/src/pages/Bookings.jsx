import { useState } from "react";
import { Link } from "react-router-dom";
import Icon from "../components/Icon";
import TicketStub from "../components/TicketStub";
import Footer from "../components/Footer";
import { useBookings } from "../context/BookingContext";
import { isPastBooking } from "../utils/format";

export default function Bookings() {
  const { bookings } = useBookings();
  const [tab, setTab] = useState("upcoming");

  const upcoming = bookings.filter((b) => b.status === "confirmed" && !isPastBooking(b));
  const past = bookings.filter((b) => b.status !== "confirmed" || isPastBooking(b));
  const list = tab === "upcoming" ? upcoming : past;

  return (
    <div className="page view-enter">
      <div className="section-head tight">
        <div>
          <div className="section-title">My bookings</div>
          <div className="section-sub">Every ticket you've reserved through ParkStub</div>
        </div>
        <Link to="/results" className="btn-amber">
          New booking <Icon name="arrowRight" size={16} />
        </Link>
      </div>

      <div className="tab-row">
        <button className={`tab-btn ${tab === "upcoming" ? "active" : ""}`} onClick={() => setTab("upcoming")}>
          Upcoming ({upcoming.length})
        </button>
        <button className={`tab-btn ${tab !== "upcoming" ? "active" : ""}`} onClick={() => setTab("past")}>
          Past &amp; cancelled ({past.length})
        </button>
      </div>

      <div className="bookings-list">
        {list.length ? (
          list.map((b) => <TicketStub key={b.id} booking={b} />)
        ) : (
          <div className="empty-state">
            <Icon name="ticket" size={32} />
            <div>
              {tab === "upcoming"
                ? "No upcoming bookings yet. Reserve a bay and your ticket will show up here."
                : "Nothing here yet."}
            </div>
          </div>
        )}
      </div>
      <Footer />
    </div>
  );
}
