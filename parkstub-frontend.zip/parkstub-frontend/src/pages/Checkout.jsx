import { useState } from "react";
import { useNavigate } from "react-router-dom";
import Icon from "../components/Icon";
import Footer from "../components/Footer";
import { PLACES } from "../data/places";
import { fmtINR } from "../utils/format";
import { useBookings } from "../context/BookingContext";
import { useToast } from "../context/ToastContext";
import { createPaymentOrder, verifyPayment } from "../services/parkingApi";

export default function Checkout() {
  const navigate = useNavigate();
  const showToast = useToast();
  const { draft, setDraft, addBooking } = useBookings();
  const [paying, setPaying] = useState(false);

  const place = draft ? PLACES.find((p) => p.id === draft.placeId) : null;

  if (!draft || !place) {
    navigate("/results");
    return null;
  }

  const fee = place.price * draft.duration;

  const pay = async () => {
    setPaying(true);
    try {
      const order = await createPaymentOrder(fee);
      await verifyPayment(order.orderId);
      const booking = addBooking({
        placeId: place.id,
        placeName: place.name,
        area: place.area,
        city: place.city,
        date: draft.date,
        startTime: draft.startTime,
        duration: draft.duration,
        slotCode: draft.slotCode,
        amount: fee,
      });
      setDraft(null);
      showToast("Payment successful — ticket generated");
      navigate(`/confirmation/${booking.id}`);
    } catch (e) {
      showToast("Payment failed — please try again");
      setPaying(false);
    }
  };

  return (
    <div className="page view-enter">
      <button className="back-link" onClick={() => navigate(`/place/${place.id}`)}>
        <Icon name="arrowLeft" size={14} /> Back to {place.name}
      </button>

      <div className="checkout-wrap">
        <div className="steps-track">
          <div className="step-pill done">
            <Icon name="check" size={12} /> Search
          </div>
          <span className="step-sep">/</span>
          <div className="step-pill done">
            <Icon name="check" size={12} /> Slot &amp; time
          </div>
          <span className="step-sep">/</span>
          <div className="step-pill current">
            <Icon name="wallet" size={12} /> Payment
          </div>
          <span className="step-sep">/</span>
          <div className="step-pill">
            <Icon name="ticket" size={12} /> QR ticket
          </div>
        </div>

        <div className="section-title" style={{ marginTop: 18 }}>
          Confirm &amp; pay
        </div>

        <div className="ticket" style={{ marginTop: 18 }}>
          <div className="ticket-main">
            <div className="ticket-brand-row">
              <div style={{ fontWeight: 700 }}>{place.name}</div>
              <div className="ticket-status status-past">Pending payment</div>
            </div>
            <div className="ticket-grid">
              <div>
                <div className="tg-label">Date</div>
                <div className="tg-value">{draft.date}</div>
              </div>
              <div>
                <div className="tg-label">Start</div>
                <div className="tg-value">{draft.startTime}</div>
              </div>
              <div>
                <div className="tg-label">Duration</div>
                <div className="tg-value">{draft.duration}h</div>
              </div>
              <div>
                <div className="tg-label">Bay</div>
                <div className="tg-value">{draft.slotCode}</div>
              </div>
              <div>
                <div className="tg-label">Location</div>
                <div className="tg-value">{place.area}</div>
              </div>
              <div>
                <div className="tg-label">Amount</div>
                <div className="tg-value amber">{fmtINR(fee)}</div>
              </div>
            </div>
          </div>
          <div className="ticket-stub-side">
            <div style={{ color: "var(--ink-dim)", fontSize: 11, textTransform: "uppercase", letterSpacing: 1 }}>
              Amount due
            </div>
            <div style={{ fontFamily: "var(--font-mono)", fontSize: 22, fontWeight: 700, color: "var(--amber)" }}>
              {fmtINR(fee)}
            </div>
          </div>
        </div>

        <div className="pay-method">
          <Icon name="wallet" />
          <div>
            <div className="name">Razorpay Checkout</div>
            <div className="sub">UPI, cards, netbanking &amp; wallets supported</div>
          </div>
        </div>

        <button className="btn-amber block" style={{ padding: 14 }} disabled={paying} onClick={pay}>
          {paying ? "Processing payment…" : `Pay ${fmtINR(fee)} securely`}
          {!paying && <Icon name="arrowRight" size={16} />}
        </button>
        <p style={{ color: "var(--ink-dim)", fontSize: 12, textAlign: "center", marginTop: 12 }}>
          Simulated checkout for demo purposes — no real charge is made.
        </p>
      </div>
      <Footer />
    </div>
  );
}
