import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import Footer from "../components/Footer";
import { useAuth } from "../context/AuthContext";

export default function Signup() {
  const { signup } = useAuth();
  const navigate = useNavigate();
  const [role, setRole] = useState("user");
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  const submit = (e) => {
    e.preventDefault();
    signup({ name, phone, email, password, role });
    navigate("/");
  };

  return (
    <div className="page view-enter">
      <div className="auth-wrap">
        <div className="auth-card">
          <h2>Create account</h2>
          <div className="sub">Sign up to book and manage your parking reservations.</div>

          <div className="role-toggle">
            <button type="button" className={role === "user" ? "active" : ""} onClick={() => setRole("user")}>
              I'm a User
            </button>
            <button type="button" className={role === "admin" ? "active" : ""} onClick={() => setRole("admin")}>
              I'm an Admin
            </button>
          </div>

          <form onSubmit={submit}>
            <div className="field">
              <label>Full name</label>
              <input value={name} onChange={(e) => setName(e.target.value)} placeholder="Your name" />
            </div>
            <div className="field">
              <label>Phone number</label>
              <input value={phone} onChange={(e) => setPhone(e.target.value)} placeholder="Your phone number" />
            </div>
            <div className="field">
              <label>Email ID</label>
              <input value={email} onChange={(e) => setEmail(e.target.value)} placeholder="you@example.com" />
            </div>
            <div className="field">
              <label>Password</label>
              <input type="password" value={password} onChange={(e) => setPassword(e.target.value)} placeholder="Choose a password" />
            </div>
            <button className="btn-amber block" type="submit" style={{ marginTop: 6 }}>
              Sign up
            </button>
          </form>

          <div className="auth-switch">
            Already have an account? <Link to="/login">Log in</Link>
          </div>
        </div>
      </div>
      <Footer />
    </div>
  );
}
