import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import Navbar from "./components/Navbar";
import Home from "./pages/Home";
import Results from "./pages/Results";
import Detail from "./pages/Detail";
import Checkout from "./pages/Checkout";
import Confirmation from "./pages/Confirmation";
import Bookings from "./pages/Bookings";
import Admin from "./pages/Admin";
import Login from "./pages/Login";
import Signup from "./pages/Signup";
import Profile from "./pages/Profile";
import { BookingProvider } from "./context/BookingContext";
import { ToastProvider } from "./context/ToastContext";
import { AuthProvider, useAuth } from "./context/AuthContext";

// Admins see the Admin dashboard; anyone else (including logged-out
// visitors) lands on Profile/Login instead — keeps admin info admin-only.
function AdminRoute() {
  const { currentUser } = useAuth();
  if (!currentUser) return <Navigate to="/login" replace />;
  if (currentUser.role !== "admin") return <Navigate to="/profile" replace />;
  return <Admin />;
}

export default function App() {
  return (
    <AuthProvider>
      <BookingProvider>
        <ToastProvider>
          <BrowserRouter>
            <Navbar />
            <Routes>
              <Route path="/" element={<Home />} />
              <Route path="/results" element={<Results />} />
              <Route path="/place/:id" element={<Detail />} />
              <Route path="/checkout" element={<Checkout />} />
              <Route path="/confirmation/:bookingId" element={<Confirmation />} />
              <Route path="/bookings" element={<Bookings />} />
              <Route path="/admin" element={<AdminRoute />} />
              <Route path="/login" element={<Login />} />
              <Route path="/signup" element={<Signup />} />
              <Route path="/profile" element={<Profile />} />
            </Routes>
          </BrowserRouter>
        </ToastProvider>
      </BookingProvider>
    </AuthProvider>
  );
}
