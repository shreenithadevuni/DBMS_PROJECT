import { useNavigate } from "react-router-dom";
import Icon, { TYPE_ICON } from "./Icon";
import { TYPE_COLOR } from "../data/places";
import { availabilityFor, fmtINR } from "../utils/format";

export default function PlaceCard({ place }) {
  const navigate = useNavigate();
  const { pct, count } = availabilityFor(place);
  const dotClass = pct > 0.4 ? "avail-good" : pct > 0.15 ? "avail-low" : "avail-none";

  return (
    <div className="place-card" onClick={() => navigate(`/place/${place.id}`)}>
      <div className="place-media" style={{ color: TYPE_COLOR[place.type] }}>
        <span className="type-badge">{place.type}</span>
        <Icon name={TYPE_ICON[place.type]} size={34} />
      </div>
      <div className="place-body">
        <div className="place-name">{place.name}</div>
        <div className="place-city">
          <Icon name="pin" size={12} />
          {place.area}, {place.city}
        </div>
        <div className="place-meta">
          <span>
            <span className={`avail-dot ${dotClass}`}></span>
            {count} free
          </span>
          <span className="price-tag">{fmtINR(place.price)}/hr</span>
        </div>
      </div>
    </div>
  );
}
