import { fmtINR, genBookingCode, isPastBooking, fakeQrCells } from "../utils/format";
import { useBookings } from "../context/BookingContext";

function QrCode({ seed }) {
  const { size, cells } = fakeQrCells(seed);
  return (
    <svg viewBox={`0 0 ${size} ${size}`} fill="#14181f">
      {cells.map(([x, y]) => (
        <rect key={`${x}-${y}`} x={x} y={y} width="1" height="1" />
      ))}
    </svg>
  );
}

export default function TicketStub({ booking }) {
  const { cancelBooking } = useBookings();
  const code = genBookingCode(booking.id);
  const past = isPastBooking(booking);

  let statusClass = "status-cancelled";
  let statusLabel = "Cancelled";
  if (booking.status === "confirmed") {
    statusClass = past ? "status-past" : "status-confirmed";
    statusLabel = past ? "Completed" : "Confirmed";
  }

  return (
    <div className="ticket">
      <div className="ticket-main">
        <div className="ticket-brand-row">
          <div>
            <div style={{ fontWeight: 700, fontSize: 16 }}>{booking.placeName}</div>
            <div className="ticket-id">
              {code} &middot; {booking.area}, {booking.city}
            </div>
          </div>
          <div className={`ticket-status ${statusClass}`}>{statusLabel}</div>
        </div>
        <div className="ticket-grid">
          <div>
            <div className="tg-label">Date</div>
            <div className="tg-value">{booking.date}</div>
          </div>
          <div>
            <div className="tg-label">Start</div>
            <div className="tg-value">{booking.startTime}</div>
          </div>
          <div>
            <div className="tg-label">Duration</div>
            <div className="tg-value">{booking.duration}h</div>
          </div>
          <div>
            <div className="tg-label">Bay</div>
            <div className="tg-value">{booking.slotCode}</div>
          </div>
          <div>
            <div className="tg-label">Amount</div>
            <div className="tg-value">{fmtINR(booking.amount)}</div>
          </div>
          <div>
            <div className="tg-label">Vehicle</div>
            <div className="tg-value">Any (demo)</div>
          </div>
        </div>
        {booking.status === "cancelled" && (
          <div style={{ marginTop: 10, fontSize: 13, color: "var(--red)" }}>
            Refund: {fmtINR(booking.refund || 0)} ({booking.refundPct || 0}% policy)
          </div>
        )}
        {booking.status === "confirmed" && !past && (
          <button className="btn-danger" style={{ marginTop: 14 }} onClick={() => cancelBooking(booking.id)}>
            Cancel booking
          </button>
        )}
      </div>
      <div className="ticket-stub-side">
        <div className="qr-wrap">
          <QrCode seed={code} />
        </div>
        <div className="stub-code">{code}</div>
      </div>
    </div>
  );
}
