export default function Footer() {
  return (
    <div className="footer">
      Built for the <b>Vehicle Parking Finder &amp; Booking App</b> project &middot; React frontend wired to a
      mock service layer — swap <code>src/services/parkingApi.js</code> for your Node/Express + MySQL backend
      and Razorpay/QR integrations.
    </div>
  );
}
