const PATHS = {
  search: <><circle cx="11" cy="11" r="7" /><line x1="21" y1="21" x2="16.65" y2="16.65" /></>,
  pin: <><path d="M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0 1 16 0Z" /><circle cx="12" cy="10" r="3" /></>,
  car: <><path d="M5 17h14M5 17a2 2 0 1 1-4 0 2 2 0 0 1 4 0Zm14 0a2 2 0 1 0 4 0 2 2 0 0 0-4 0ZM3 17V11l2-5h14l2 5v6" /><path d="M5 11h14" /></>,
  clock: <><circle cx="12" cy="12" r="9" /><path d="M12 7v5l3 3" /></>,
  calendar: <><rect x="3" y="5" width="18" height="16" rx="2" /><path d="M16 3v4M8 3v4M3 10h18" /></>,
  check: <path d="M20 6 9 17l-5-5" strokeWidth="2.4" />,
  arrowRight: <path d="M5 12h14M13 5l7 7-7 7" strokeWidth="2.2" />,
  arrowLeft: <path d="M19 12H5M11 19l-7-7 7-7" strokeWidth="2.2" />,
  ticket: <><path d="M3 8a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2v2a2 2 0 0 0 0 4v2a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-2a2 2 0 0 0 0-4Z" /><path d="M13 5v14" strokeDasharray="2 3" /></>,
  shield: <path d="M12 2 4 5v6c0 5 3.5 9 8 11 4.5-2 8-6 8-11V5Z" />,
  home: <><path d="M3 10.5 12 3l9 7.5" /><path d="M5 9.5V21h14V9.5" /></>,
  bag: <><path d="M6 7h12l1 13H5L6 7Z" /><path d="M9 7a3 3 0 0 1 6 0" /></>,
  monument: <><path d="M12 2l7 5v2H5V7l7-5Z" /><path d="M5 21V11M19 21V11M9 21V13M15 21V13M3 21h18" /></>,
  temple: <><path d="M12 2v3M12 5 4 11h16L12 5Z" /><path d="M4 11v10h16V11M8 21v-6h8v6" /></>,
  castle: <><path d="M4 21V9l3 2V7l2 2V7l3-2 3 2V7l2 2V9l3-2v12H4Z" /><path d="M4 21h16" /></>,
  stadium: <><ellipse cx="12" cy="12" rx="9" ry="6" /><ellipse cx="12" cy="12" rx="5" ry="3" /></>,
  tree: <><path d="M12 2 6 12h4l-3 6h10l-3-6h4L12 2Z" /><path d="M12 18v4" /></>,
  plane: <path d="M2 16l20-6-6 8 2 6-6-4-6 4 2-6-6-2Z" />,
  x: <path d="M18 6 6 18M6 6l12 12" strokeWidth="2.2" />,
  wallet: <path d="M3 7a2 2 0 0 1 2-2h13a1 1 0 0 1 1 1v3M3 7v11a2 2 0 0 0 2 2h15a1 1 0 0 0 1-1v-6a1 1 0 0 0-1-1h-5a2 2 0 1 0 0 4h5" />,
  layers: <><path d="m12 2 9 5-9 5-9-5 9-5Z" /><path d="m3 12 9 5 9-5M3 17l9 5 9-5" /></>,
};

export const TYPE_ICON = {
  Mall: "bag",
  Landmark: "monument",
  Temple: "temple",
  Fort: "castle",
  Stadium: "stadium",
  Park: "tree",
  Transit: "plane",
};

export default function Icon({ name, size = 18, style, className }) {
  const path = PATHS[name];
  if (!path) return null;
  return (
    <svg
      viewBox="0 0 24 24"
      width={size}
      height={size}
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      style={style}
      className={className}
    >
      {path}
    </svg>
  );
}
