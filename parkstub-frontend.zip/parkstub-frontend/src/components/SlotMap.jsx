export default function SlotMap({ slots, selectedCode, onSelect }) {
  return (
    <>
      <div className="slot-legend">
        <div className="legend-item">
          <span
            className="legend-swatch"
            style={{ background: "rgba(53,201,122,0.15)", border: "1px solid rgba(53,201,122,0.5)" }}
          ></span>
          Available
        </div>
        <div className="legend-item">
          <span
            className="legend-swatch"
            style={{ background: "rgba(255,176,32,0.15)", border: "1px solid rgba(255,176,32,0.5)" }}
          ></span>
          Reserved
        </div>
        <div className="legend-item">
          <span
            className="legend-swatch"
            style={{ background: "rgba(228,88,79,0.1)", border: "1px solid rgba(228,88,79,0.4)" }}
          ></span>
          Occupied
        </div>
        <div className="legend-item">
          <span className="legend-swatch" style={{ background: "var(--amber)" }}></span>
          Your pick
        </div>
      </div>
      <div className="slot-map">
        {slots.map((s) => (
          <div
            key={s.code}
            className={`slot ${s.status} ${selectedCode === s.code ? "selected" : ""}`}
            onClick={() => s.status === "available" && onSelect(s.code)}
          >
            {s.code}
          </div>
        ))}
      </div>
    </>
  );
}
