import { NavLink, useNavigate } from "react-router-dom";
import Icon from "./Icon";
import { useBookings } from "../context/BookingContext";
import { useAuth } from "../context/AuthContext";

const BASE_LINKS = [
  { to: "/", label: "Home", icon: "home", end: true },
  { to: "/results", label: "Find Parking", icon: "search" },
  { to: "/bookings", label: "My Bookings", icon: "ticket", showCount: true },
];

export default function Navbar() {
  const { bookings } = useBookings();
  const { currentUser, logout } = useAuth();
  const navigate = useNavigate();
  const upcomingCount = bookings.filter((b) => b.status === "confirmed").length;

  // Everyone sees Home / Find Parking / My Bookings. Beyond that:
  // an admin sees the Admin dashboard, a regular user sees their Profile.
  const roleLink =
    currentUser?.role === "admin"
      ? { to: "/admin", label: "Admin", icon: "layers" }
      : { to: "/profile", label: "Profile", icon: "shield" };

  const links = currentUser ? [...BASE_LINKS, roleLink] : BASE_LINKS;

  const initial = currentUser?.name?.trim()?.[0]?.toUpperCase() || "?";

  return (
    <div className="topnav">
      <NavLink to="/" className="brand">
        <div className="brand-mark">
          <Icon name="car" size={18} />
        </div>
        <div className="brand-name">
          Park<span>Stub</span>
        </div>
      </NavLink>
      <div className="nav-links">
        {links.map((link) => (
          <NavLink
            key={link.to}
            to={link.to}
            end={link.end}
            className={({ isActive }) => "nav-btn" + (isActive ? " active" : "")}
          >
            <Icon name={link.icon} size={16} />
            <span className="nav-label">{link.label}</span>
            {link.showCount && upcomingCount > 0 && <span className="nav-count">{upcomingCount}</span>}
          </NavLink>
        ))}

        {currentUser ? (
          <div className="nav-user">
            <div className="avatar">{initial}</div>
            <div>
              <div className="uname">{currentUser.name || "Account"}</div>
              <div className="role-tag">{currentUser.role}</div>
            </div>
            <button
              className="nav-btn"
              onClick={() => {
                logout();
                navigate("/");
              }}
            >
              <Icon name="x" size={14} />
            </button>
          </div>
        ) : (
          <>
            <NavLink to="/login" className={({ isActive }) => "nav-btn" + (isActive ? " active" : "")}>
              <span className="nav-label">Log in</span>
            </NavLink>
            <NavLink to="/signup" className="btn-amber" style={{ height: 36, padding: "0 16px" }}>
              Sign up
            </NavLink>
          </>
        )}
      </div>
    </div>
  );
}
