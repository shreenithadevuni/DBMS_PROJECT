import { createContext, useCallback, useContext, useState } from "react";

const AuthContext = createContext(null);

/**
 * In-memory auth for the demo (no backend yet, and no localStorage —
 * this sandbox disallows browser storage). Swap this for real
 * signup/login calls to your Express API when it's ready.
 *
 * Deliberately no field validation beyond "not empty" — the person can
 * type whatever they want into name/phone/email/password.
 */
export function AuthProvider({ children }) {
  const [users, setUsers] = useState([]); // [{name, phone, email, password, role}]
  const [currentUser, setCurrentUser] = useState(null);

  const signup = useCallback(({ name, phone, email, password, role }) => {
    const user = { name, phone, email, password, role: role || "user" };
    setUsers((prev) => [...prev.filter((u) => u.email !== email), user]);
    setCurrentUser(user);
    return user;
  }, []);

  const login = useCallback(
    ({ email, password }) => {
      const found = users.find((u) => u.email === email && u.password === password);
      if (!found) return { ok: false, error: "No account matches that email and password." };
      setCurrentUser(found);
      return { ok: true, user: found };
    },
    [users]
  );

  const logout = useCallback(() => setCurrentUser(null), []);

  return (
    <AuthContext.Provider value={{ currentUser, signup, login, logout }}>{children}</AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be used within an AuthProvider");
  return ctx;
}
