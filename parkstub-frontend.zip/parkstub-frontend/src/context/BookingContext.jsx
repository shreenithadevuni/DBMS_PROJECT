import { createContext, useCallback, useContext, useRef, useState } from "react";

const BookingContext = createContext(null);

/**
 * Holds booking state for the session. In-memory only (no localStorage —
 * artifacts/sandboxes disallow it, and it keeps this a clean drop-in
 * spot for a real API layer later — see src/services/parkingApi.js).
 */
export function BookingProvider({ children }) {
  const [bookings, setBookings] = useState([]);
  const [draft, setDraft] = useState(null); // { placeId, date, startTime, duration, slotCode }
  const seqRef = useRef(1001);

  const addBooking = useCallback((booking) => {
    const id = seqRef.current++;
    const record = { id, status: "confirmed", createdAt: Date.now(), ...booking };
    setBookings((prev) => [record, ...prev]);
    return record;
  }, []);

  const cancelBooking = useCallback((id) => {
    setBookings((prev) =>
      prev.map((b) => {
        if (b.id !== id) return b;
        const startDt = new Date(`${b.date}T${b.startTime}:00`);
        const hoursLeft = (startDt.getTime() - Date.now()) / 3600000;
        const refundPct = hoursLeft >= 24 ? 100 : hoursLeft >= 2 ? 50 : 0;
        const refund = Math.round((b.amount * refundPct) / 100);
        return { ...b, status: "cancelled", refundPct, refund };
      })
    );
  }, []);

  const value = { bookings, draft, setDraft, addBooking, cancelBooking };
  return <BookingContext.Provider value={value}>{children}</BookingContext.Provider>;
}

export function useBookings() {
  const ctx = useContext(BookingContext);
  if (!ctx) throw new Error("useBookings must be used within a BookingProvider");
  return ctx;
}
