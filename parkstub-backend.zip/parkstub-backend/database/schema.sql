-- Run this after: CREATE DATABASE parkstub; USE parkstub;

CREATE TABLE IF NOT EXISTS users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(120) NOT NULL,
  email VARCHAR(150) NOT NULL UNIQUE,
  phone VARCHAR(20),
  password_hash VARCHAR(255) NOT NULL,
  role ENUM('user', 'admin') NOT NULL DEFAULT 'user',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS vehicles (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  vehicle_number VARCHAR(20) NOT NULL,
  vehicle_type VARCHAR(30) DEFAULT 'Car',
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS parking_locations (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(150) NOT NULL,
  city VARCHAR(80) NOT NULL,
  area VARCHAR(120),
  type VARCHAR(30) NOT NULL DEFAULT 'Mall',
  total_slots INT NOT NULL DEFAULT 50,
  price_per_hour DECIMAL(10, 2) NOT NULL DEFAULT 20.00
);

-- One row per physical bay at a location (A1, A2, B1 ...).
CREATE TABLE IF NOT EXISTS parking_slots (
  id INT AUTO_INCREMENT PRIMARY KEY,
  parking_id INT NOT NULL,
  slot_code VARCHAR(10) NOT NULL,
  FOREIGN KEY (parking_id) REFERENCES parking_locations(id) ON DELETE CASCADE,
  UNIQUE KEY unique_slot_per_location (parking_id, slot_code)
);

CREATE TABLE IF NOT EXISTS bookings (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  vehicle_id INT NULL,
  parking_id INT NOT NULL,
  slot_id INT NOT NULL,
  booking_date DATE NOT NULL,
  start_time TIME NOT NULL,
  duration_hours INT NOT NULL,
  amount DECIMAL(10, 2) NOT NULL,
  booking_status ENUM('pending_payment', 'confirmed', 'cancelled', 'completed') NOT NULL DEFAULT 'pending_payment',
  refund_amount DECIMAL(10, 2) DEFAULT 0,
  refund_pct INT DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (vehicle_id) REFERENCES vehicles(id) ON DELETE SET NULL,
  FOREIGN KEY (parking_id) REFERENCES parking_locations(id),
  FOREIGN KEY (slot_id) REFERENCES parking_slots(id)
);

CREATE TABLE IF NOT EXISTS payments (
  id INT AUTO_INCREMENT PRIMARY KEY,
  booking_id INT NOT NULL,
  amount DECIMAL(10, 2) NOT NULL,
  payment_method VARCHAR(30) DEFAULT 'razorpay',
  order_id VARCHAR(100),
  transaction_id VARCHAR(100),
  payment_status ENUM('created', 'paid', 'failed', 'refunded') NOT NULL DEFAULT 'created',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (booking_id) REFERENCES bookings(id) ON DELETE CASCADE
);
