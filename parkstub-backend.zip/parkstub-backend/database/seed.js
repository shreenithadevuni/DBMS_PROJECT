// Generates parking_slots rows (A1, A2, B1 ...) for every location that
// doesn't have any bays yet. Run this once after schema.sql + seed.sql.
require("dotenv").config();
const pool = require("../config/db");

const ROWS = "ABCD";
const MAX_BAYS = 48; // matches the visual cap used on the frontend's slot map

function buildSlotCodes(totalSlots) {
  const total = Math.min(totalSlots, MAX_BAYS);
  const perRow = Math.ceil(total / 4);
  const codes = [];
  let i = 0;
  for (const r of ROWS) {
    for (let c = 1; c <= perRow; c++) {
      if (i >= total) break;
      codes.push(`${r}${c}`);
      i++;
    }
  }
  return codes;
}

async function run() {
  const [locations] = await pool.query("SELECT id, total_slots FROM parking_locations");

  for (const loc of locations) {
    const [existing] = await pool.query("SELECT COUNT(*) as count FROM parking_slots WHERE parking_id = ?", [loc.id]);
    if (existing[0].count > 0) continue; // already seeded

    const codes = buildSlotCodes(loc.total_slots);
    const values = codes.map((code) => [loc.id, code]);
    await pool.query("INSERT INTO parking_slots (parking_id, slot_code) VALUES ?", [values]);
    console.log(`Seeded ${codes.length} bays for location #${loc.id}`);
  }

  console.log("Done seeding bays.");
  process.exit(0);
}

run().catch((err) => {
  console.error(err);
  process.exit(1);
});
