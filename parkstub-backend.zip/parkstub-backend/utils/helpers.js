function genBookingCode(id) {
  return "PS" + String(id).padStart(6, "0");
}

// >=24h before start: 100% refund, 2-24h: 50%, <2h: 0% — same policy the frontend shows.
function calcRefund(amount, bookingDate, startTime) {
  const startDt = new Date(`${bookingDate}T${startTime}`);
  const hoursLeft = (startDt.getTime() - Date.now()) / 3600000;
  const pct = hoursLeft >= 24 ? 100 : hoursLeft >= 2 ? 50 : 0;
  const refund = Math.round((amount * pct) / 100);
  return { pct, refund };
}

module.exports = { genBookingCode, calcRefund };
