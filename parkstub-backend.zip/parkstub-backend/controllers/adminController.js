const pool = require("../config/db");
const { genBookingCode } = require("../utils/helpers");

async function getStats(req, res) {
  try {
    const [[{ locations }]] = await pool.query("SELECT COUNT(*) AS locations FROM parking_locations");
    const [[{ totalBays }]] = await pool.query("SELECT COUNT(*) AS totalBays FROM parking_slots");
    const [[{ totalBookings }]] = await pool.query("SELECT COUNT(*) AS totalBookings FROM bookings");
    const [[{ revenue }]] = await pool.query(
      "SELECT COALESCE(SUM(amount), 0) AS revenue FROM bookings WHERE booking_status IN ('confirmed', 'completed')"
    );
    const [[{ cancellations }]] = await pool.query(
      "SELECT COUNT(*) AS cancellations FROM bookings WHERE booking_status = 'cancelled'"
    );
    const [[{ refunded }]] = await pool.query(
      "SELECT COALESCE(SUM(refund_amount), 0) AS refunded FROM bookings WHERE booking_status = 'cancelled'"
    );

    res.json({ locations, totalBays, totalBookings, revenue, cancellations, refunded });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Could not load admin stats." });
  }
}

async function listAllBookings(req, res) {
  try {
    const [rows] = await pool.query(
      `SELECT b.*, pl.name AS place_name, ps.slot_code, u.name AS user_name
       FROM bookings b
       JOIN parking_locations pl ON pl.id = b.parking_id
       JOIN parking_slots ps ON ps.id = b.slot_id
       JOIN users u ON u.id = b.user_id
       ORDER BY b.created_at DESC
       LIMIT 200`
    );
    const bookings = rows.map((r) => ({
      id: r.id,
      code: genBookingCode(r.id),
      placeName: r.place_name,
      slotCode: r.slot_code,
      userName: r.user_name,
      date: r.booking_date,
      startTime: r.start_time,
      amount: r.amount,
      status: r.booking_status,
    }));
    res.json({ bookings });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Could not load bookings." });
  }
}

module.exports = { getStats, listAllBookings };
