const pool = require("../config/db");

async function listPlaces(req, res) {
  try {
    const { query = "", city = "All Cities", type = "All Types" } = req.query;
    const clauses = [];
    const params = [];

    if (query.trim()) {
      clauses.push("(name LIKE ? OR city LIKE ? OR area LIKE ?)");
      const like = `%${query.trim()}%`;
      params.push(like, like, like);
    }
    if (city && city !== "All Cities") {
      clauses.push("city = ?");
      params.push(city);
    }
    if (type && type !== "All Types") {
      clauses.push("type = ?");
      params.push(type);
    }

    const where = clauses.length ? `WHERE ${clauses.join(" AND ")}` : "";
    const [rows] = await pool.query(`SELECT * FROM parking_locations ${where} ORDER BY name`, params);
    res.json({ places: rows });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Could not load locations." });
  }
}

async function getPlace(req, res) {
  try {
    const [rows] = await pool.query("SELECT * FROM parking_locations WHERE id = ?", [req.params.id]);
    if (!rows[0]) return res.status(404).json({ error: "Location not found." });
    res.json({ place: rows[0] });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Could not load location." });
  }
}

// Returns every bay for a location plus its status for the given date,
// based on real bookings instead of random demo data.
async function getSlots(req, res) {
  try {
    const { date } = req.query;
    if (!date) return res.status(400).json({ error: "A date query param (YYYY-MM-DD) is required." });

    const [rows] = await pool.query(
      `SELECT ps.id, ps.slot_code,
              (SELECT b.booking_status FROM bookings b
                 WHERE b.slot_id = ps.id AND b.booking_date = ?
                   AND b.booking_status IN ('pending_payment', 'confirmed')
                 LIMIT 1) AS active_status
       FROM parking_slots ps
       WHERE ps.parking_id = ?
       ORDER BY ps.slot_code`,
      [date, req.params.id]
    );

    const slots = rows.map((r) => ({
      id: r.id,
      code: r.slot_code,
      status: r.active_status === "confirmed" ? "occupied" : r.active_status === "pending_payment" ? "reserved" : "available",
    }));

    res.json({ slots });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Could not load bay availability." });
  }
}

module.exports = { listPlaces, getPlace, getSlots };
