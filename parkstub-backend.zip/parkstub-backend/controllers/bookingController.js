const QRCode = require("qrcode");
const pool = require("../config/db");
const { genBookingCode, calcRefund } = require("../utils/helpers");

let razorpay = null;
if (process.env.DEMO_MODE !== "true") {
  const Razorpay = require("razorpay");
  razorpay = new Razorpay({
    key_id: process.env.RAZORPAY_KEY_ID,
    key_secret: process.env.RAZORPAY_KEY_SECRET,
  });
}

// POST /api/bookings — reserve a bay and open a payment order.
async function createBooking(req, res) {
  const conn = await pool.getConnection();
  try {
    const { placeId, slotId, date, startTime, duration } = req.body;
    if (!placeId || !slotId || !date || !startTime || !duration) {
      return res.status(400).json({ error: "placeId, slotId, date, startTime and duration are all required." });
    }

    await conn.beginTransaction();

    const [[place]] = await conn.query("SELECT * FROM parking_locations WHERE id = ?", [placeId]);
    if (!place) throw { status: 404, message: "Location not found." };

    const [clash] = await conn.query(
      `SELECT id FROM bookings WHERE slot_id = ? AND booking_date = ?
         AND booking_status IN ('pending_payment', 'confirmed') LIMIT 1`,
      [slotId, date]
    );
    if (clash.length) throw { status: 409, message: "That bay is no longer available for this date." };

    const amount = Number(place.price_per_hour) * Number(duration);

    const [result] = await conn.query(
      `INSERT INTO bookings (user_id, parking_id, slot_id, booking_date, start_time, duration_hours, amount, booking_status)
       VALUES (?, ?, ?, ?, ?, ?, ?, 'pending_payment')`,
      [req.user.id, placeId, slotId, date, startTime, duration, amount]
    );
    const bookingId = result.insertId;

    let orderId = "demo_order_" + bookingId;
    if (razorpay) {
      const order = await razorpay.orders.create({ amount: Math.round(amount * 100), currency: "INR", receipt: `booking_${bookingId}` });
      orderId = order.id;
    }

    await conn.query(
      "INSERT INTO payments (booking_id, amount, order_id, payment_status) VALUES (?, ?, ?, 'created')",
      [bookingId, amount, orderId]
    );

    await conn.commit();
    res.status(201).json({ bookingId, orderId, amount, razorpayKeyId: process.env.RAZORPAY_KEY_ID || null });
  } catch (err) {
    await conn.rollback();
    console.error(err);
    res.status(err.status || 500).json({ error: err.message || "Could not create booking." });
  } finally {
    conn.release();
  }
}

// POST /api/bookings/:id/pay — confirm payment and generate the QR ticket.
// In DEMO_MODE this just marks it paid; wire in Razorpay's signature
// verification here once you have real keys (see Razorpay docs).
async function payBooking(req, res) {
  try {
    const bookingId = req.params.id;
    const [[booking]] = await pool.query(
      `SELECT b.*, pl.name AS place_name, pl.area, pl.city, ps.slot_code
       FROM bookings b
       JOIN parking_locations pl ON pl.id = b.parking_id
       JOIN parking_slots ps ON ps.id = b.slot_id
       WHERE b.id = ? AND b.user_id = ?`,
      [bookingId, req.user.id]
    );
    if (!booking) return res.status(404).json({ error: "Booking not found." });

    await pool.query("UPDATE payments SET payment_status = 'paid', transaction_id = ? WHERE booking_id = ?", [
      "txn_" + Date.now(),
      bookingId,
    ]);
    await pool.query("UPDATE bookings SET booking_status = 'confirmed' WHERE id = ?", [bookingId]);

    const code = genBookingCode(bookingId);
    const qrPayload = JSON.stringify({ code, placeId: booking.parking_id, date: booking.booking_date, slot: booking.slot_code });
    const qrDataUrl = await QRCode.toDataURL(qrPayload);

    res.json({
      booking: {
        id: booking.id,
        code,
        placeName: booking.place_name,
        area: booking.area,
        city: booking.city,
        date: booking.booking_date,
        startTime: booking.start_time,
        duration: booking.duration_hours,
        slotCode: booking.slot_code,
        amount: booking.amount,
        status: "confirmed",
      },
      qrDataUrl,
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Payment confirmation failed." });
  }
}

// GET /api/bookings — the logged-in user's own bookings.
async function listMyBookings(req, res) {
  try {
    const [rows] = await pool.query(
      `SELECT b.*, pl.name AS place_name, pl.area, pl.city, ps.slot_code
       FROM bookings b
       JOIN parking_locations pl ON pl.id = b.parking_id
       JOIN parking_slots ps ON ps.id = b.slot_id
       WHERE b.user_id = ?
       ORDER BY b.created_at DESC`,
      [req.user.id]
    );
    const bookings = rows.map((r) => ({
      id: r.id,
      code: genBookingCode(r.id),
      placeName: r.place_name,
      area: r.area,
      city: r.city,
      date: r.booking_date,
      startTime: r.start_time,
      duration: r.duration_hours,
      slotCode: r.slot_code,
      amount: r.amount,
      status: r.booking_status,
      refund: r.refund_amount,
      refundPct: r.refund_pct,
    }));
    res.json({ bookings });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Could not load bookings." });
  }
}

// POST /api/bookings/:id/cancel — same 100/50/0% window policy as the frontend.
async function cancelBooking(req, res) {
  try {
    const [[booking]] = await pool.query("SELECT * FROM bookings WHERE id = ? AND user_id = ?", [req.params.id, req.user.id]);
    if (!booking) return res.status(404).json({ error: "Booking not found." });
    if (booking.booking_status !== "confirmed") {
      return res.status(400).json({ error: "Only confirmed bookings can be cancelled." });
    }

    const { pct, refund } = calcRefund(Number(booking.amount), booking.booking_date, booking.start_time);

    await pool.query(
      "UPDATE bookings SET booking_status = 'cancelled', refund_amount = ?, refund_pct = ? WHERE id = ?",
      [refund, pct, booking.id]
    );
    await pool.query("UPDATE payments SET payment_status = 'refunded' WHERE booking_id = ?", [booking.id]);

    res.json({ bookingId: booking.id, refundPct: pct, refund });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Cancellation failed." });
  }
}

module.exports = { createBooking, payBooking, listMyBookings, cancelBooking };
