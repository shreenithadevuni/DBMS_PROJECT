const express = require("express");
const { createBooking, payBooking, listMyBookings, cancelBooking } = require("../controllers/bookingController");
const { requireAuth } = require("../middleware/auth");

const router = express.Router();

router.use(requireAuth);
router.get("/", listMyBookings);
router.post("/", createBooking);
router.post("/:id/pay", payBooking);
router.post("/:id/cancel", cancelBooking);

module.exports = router;
