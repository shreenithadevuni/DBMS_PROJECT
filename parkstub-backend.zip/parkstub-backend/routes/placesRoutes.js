const express = require("express");
const { listPlaces, getPlace, getSlots } = require("../controllers/placesController");

const router = express.Router();

router.get("/", listPlaces);
router.get("/:id", getPlace);
router.get("/:id/slots", getSlots);

module.exports = router;
