const express = require("express");
const { getStats, listAllBookings } = require("../controllers/adminController");
const { requireAuth, requireAdmin } = require("../middleware/auth");

const router = express.Router();

router.use(requireAuth, requireAdmin);
router.get("/stats", getStats);
router.get("/bookings", listAllBookings);

module.exports = router;
